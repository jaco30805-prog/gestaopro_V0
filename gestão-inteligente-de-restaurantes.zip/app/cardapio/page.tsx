"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Plus, Search, Filter, TrendingUp, TrendingDown, UtensilsCrossed, AlertTriangle, ChefHat } from "lucide-react"

const mockMenu = [
  { id: 1, name: "X-Burguer Clássico", category: "Lanches", cost: 8.50, price: 24.00, sales: 145, status: "high-profit" },
  { id: 2, name: "X-Salada", category: "Lanches", cost: 10.50, price: 15.00, sales: 89, status: "low-profit" },
  { id: 3, name: "Batata Frita (Porção)", category: "Acompanhamentos", cost: 3.20, price: 18.00, sales: 210, status: "high-profit" },
  { id: 4, name: "Refrigerante Lata", category: "Bebidas", cost: 2.50, price: 6.00, sales: 340, status: "good-profit" },
  { id: 5, name: "Combo Família", category: "Combos", cost: 35.00, price: 69.90, sales: 45, status: "good-profit" },
  { id: 6, name: "Hambúrguer Artesanal Duplo", category: "Lanches Premium", cost: 18.40, price: 38.00, sales: 62, status: "warning" },
]

export default function CardapioPage() {
  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-zinc-900">Engenharia de Cardápio</h2>
          <p className="text-zinc-500 mt-1">Gerencie seus pratos, fichas técnicas e margens de lucro.</p>
        </div>
        <div className="flex items-center gap-3">
          <button className="inline-flex items-center justify-center rounded-xl bg-emerald-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-emerald-700 transition-colors">
            <Plus className="mr-2 h-4 w-4" />
            Novo Prato
          </button>
        </div>
      </div>

      {/* Filtros e Busca */}
      <div className="flex flex-col sm:flex-row gap-4 items-center justify-between bg-white p-4 rounded-2xl border border-zinc-200 shadow-sm">
        <div className="relative w-full sm:w-96">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-400" />
          <input
            type="text"
            placeholder="Buscar prato ou categoria..."
            className="w-full pl-10 pr-4 py-2 bg-zinc-50 border border-zinc-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
          />
        </div>
        <div className="flex items-center gap-2 w-full sm:w-auto overflow-x-auto pb-2 sm:pb-0">
          <button className="whitespace-nowrap px-4 py-2 rounded-lg bg-zinc-900 text-white text-sm font-medium">Todos</button>
          <button className="whitespace-nowrap px-4 py-2 rounded-lg bg-zinc-100 text-zinc-600 hover:bg-zinc-200 text-sm font-medium transition-colors">Lanches</button>
          <button className="whitespace-nowrap px-4 py-2 rounded-lg bg-zinc-100 text-zinc-600 hover:bg-zinc-200 text-sm font-medium transition-colors">Bebidas</button>
          <button className="p-2 border border-zinc-200 rounded-lg text-zinc-500 hover:bg-zinc-50 ml-auto sm:ml-2">
            <Filter className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Grid de Pratos */}
      <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
        {mockMenu.map((item) => {
          const profit = item.price - item.cost
          const margin = (profit / item.price) * 100

          return (
            <Card key={item.id} className="overflow-hidden hover:shadow-md transition-shadow cursor-pointer group">
              <CardContent className="p-0">
                <div className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div className="h-12 w-12 bg-zinc-100 rounded-xl flex items-center justify-center text-zinc-500 group-hover:bg-emerald-50 group-hover:text-emerald-600 transition-colors">
                      <ChefHat className="h-6 w-6" />
                    </div>
                    {item.status === 'high-profit' && (
                      <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-700">
                        <TrendingUp className="h-3 w-3 mr-1" /> Estrela
                      </span>
                    )}
                    {item.status === 'low-profit' && (
                      <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-rose-100 text-rose-700">
                        <TrendingDown className="h-3 w-3 mr-1" /> Prejuízo
                      </span>
                    )}
                    {item.status === 'warning' && (
                      <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-100 text-amber-700">
                        <AlertTriangle className="h-3 w-3 mr-1" /> Atenção
                      </span>
                    )}
                  </div>
                  
                  <h3 className="text-lg font-bold text-zinc-900 truncate">{item.name}</h3>
                  <p className="text-sm text-zinc-500 mb-6">{item.category}</p>

                  <div className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-zinc-500">Custo (Ingredientes)</span>
                      <span className="font-medium text-zinc-900">R$ {item.cost.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-zinc-500">Preço de Venda</span>
                      <span className="font-medium text-zinc-900">R$ {item.price.toFixed(2)}</span>
                    </div>
                    <div className="pt-3 border-t border-zinc-100 flex justify-between items-center">
                      <span className="text-sm font-medium text-zinc-900">Lucro Bruto</span>
                      <div className="text-right">
                        <span className={`font-bold ${margin >= 50 ? 'text-emerald-600' : margin <= 30 ? 'text-rose-600' : 'text-zinc-900'}`}>
                          R$ {profit.toFixed(2)}
                        </span>
                        <span className="text-xs text-zinc-500 ml-2">({margin.toFixed(1)}%)</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="bg-zinc-50 px-6 py-3 border-t border-zinc-100 flex justify-between items-center">
                  <span className="text-xs text-zinc-500">{item.sales} vendas este mês</span>
                  <button className="text-xs font-medium text-emerald-600 hover:text-emerald-700">Ver Ficha Técnica &rarr;</button>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
