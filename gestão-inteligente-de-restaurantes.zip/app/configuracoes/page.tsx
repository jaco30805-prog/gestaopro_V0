"use client"

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Store, Bell, Link as LinkIcon, Users, Save, Smartphone } from "lucide-react"

export default function ConfiguracoesPage() {
  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      <div>
        <h2 className="text-2xl md:text-3xl font-bold tracking-tight text-zinc-900">Configurações</h2>
        <p className="text-zinc-500 mt-1">Gerencie as preferências e integrações do seu restaurante.</p>
      </div>

      <div className="grid gap-8 md:grid-cols-3">
        {/* Menu lateral de configurações (Desktop) */}
        <div className="hidden md:flex flex-col gap-2">
          <a href="#perfil" className="px-4 py-2 rounded-xl bg-zinc-200/80 text-zinc-900 font-medium text-sm">Perfil do Restaurante</a>
          <a href="#integracoes" className="px-4 py-2 rounded-xl text-zinc-600 hover:bg-zinc-100 font-medium text-sm transition-colors">Integrações (PDV & Delivery)</a>
          <a href="#notificacoes" className="px-4 py-2 rounded-xl text-zinc-600 hover:bg-zinc-100 font-medium text-sm transition-colors">Notificações</a>
          <a href="#equipe" className="px-4 py-2 rounded-xl text-zinc-600 hover:bg-zinc-100 font-medium text-sm transition-colors">Equipe e Acessos</a>
        </div>

        {/* Conteúdo das configurações */}
        <div className="md:col-span-2 space-y-8">
          {/* Perfil */}
          <Card id="perfil">
            <CardHeader>
              <CardTitle className="flex items-center text-lg">
                <Store className="w-5 h-5 mr-2 text-zinc-500" />
                Perfil do Restaurante
              </CardTitle>
              <CardDescription>Informações básicas do seu estabelecimento.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-zinc-700">Nome do Restaurante</label>
                  <input type="text" defaultValue="Burger & Co." className="w-full px-3 py-2 bg-zinc-50 border border-zinc-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-zinc-700">CNPJ</label>
                  <input type="text" defaultValue="12.345.678/0001-90" className="w-full px-3 py-2 bg-zinc-50 border border-zinc-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500" />
                </div>
                <div className="space-y-2 sm:col-span-2">
                  <label className="text-sm font-medium text-zinc-700">Endereço</label>
                  <input type="text" defaultValue="Av. Paulista, 1000 - São Paulo, SP" className="w-full px-3 py-2 bg-zinc-50 border border-zinc-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500" />
                </div>
              </div>
              <div className="flex justify-end pt-4">
                <button className="inline-flex items-center justify-center rounded-xl bg-emerald-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-emerald-700 transition-colors">
                  <Save className="w-4 h-4 mr-2" />
                  Salvar Alterações
                </button>
              </div>
            </CardContent>
          </Card>

          {/* Integrações */}
          <Card id="integracoes">
            <CardHeader>
              <CardTitle className="flex items-center text-lg">
                <LinkIcon className="w-5 h-5 mr-2 text-zinc-500" />
                Integrações
              </CardTitle>
              <CardDescription>Conecte seu PDV e aplicativos de delivery para sincronização automática.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-4 border border-zinc-200 rounded-xl">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center text-red-600 font-bold text-xl">i</div>
                  <div>
                    <h4 className="text-sm font-semibold text-zinc-900">iFood</h4>
                    <p className="text-xs text-zinc-500">Sincronizar cardápio e vendas</p>
                  </div>
                </div>
                <button className="px-3 py-1.5 text-xs font-medium text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-lg hover:bg-emerald-100 transition-colors">
                  Conectado
                </button>
              </div>
              
              <div className="flex items-center justify-between p-4 border border-zinc-200 rounded-xl">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-zinc-100 rounded-lg flex items-center justify-center text-zinc-600">
                    <Smartphone className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-zinc-900">Consumer (PDV)</h4>
                    <p className="text-xs text-zinc-500">Importação automática de cupons</p>
                  </div>
                </div>
                <button className="px-3 py-1.5 text-xs font-medium text-zinc-700 bg-white border border-zinc-200 rounded-lg hover:bg-zinc-50 transition-colors">
                  Conectar
                </button>
              </div>
            </CardContent>
          </Card>

          {/* Notificações */}
          <Card id="notificacoes">
            <CardHeader>
              <CardTitle className="flex items-center text-lg">
                <Bell className="w-5 h-5 mr-2 text-zinc-500" />
                Notificações
              </CardTitle>
              <CardDescription>Escolha como deseja ser avisado sobre o seu negócio.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between py-2">
                <div className="pr-4">
                  <h4 className="text-sm font-medium text-zinc-900">Alertas de Estoque Baixo</h4>
                  <p className="text-xs text-zinc-500">Receber aviso quando um ingrediente atingir o nível mínimo.</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer flex-shrink-0">
                  <input type="checkbox" className="sr-only peer" defaultChecked />
                  <div className="w-11 h-6 bg-zinc-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-emerald-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-zinc-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                </label>
              </div>
              <div className="flex items-center justify-between py-2">
                <div className="pr-4">
                  <h4 className="text-sm font-medium text-zinc-900">Resumo Diário no WhatsApp</h4>
                  <p className="text-xs text-zinc-500">Receber faturamento e lucro estimado ao fim do dia.</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer flex-shrink-0">
                  <input type="checkbox" className="sr-only peer" />
                  <div className="w-11 h-6 bg-zinc-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-emerald-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-zinc-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                </label>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
