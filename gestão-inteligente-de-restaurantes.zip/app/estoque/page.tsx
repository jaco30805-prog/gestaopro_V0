"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Camera, Plus, Search, Filter, AlertCircle, CheckCircle2, UploadCloud, FileText } from "lucide-react"

// Dados simulados do estoque
const mockInventory = [
  { id: 1, name: "Contra-filé", category: "Carnes", quantity: 12, unit: "kg", cost: 38.90, status: "warning", minStock: 15 },
  { id: 2, name: "Tomate Carmem", category: "Hortifruti", quantity: 5, unit: "kg", cost: 6.50, status: "warning", minStock: 10 },
  { id: 3, name: "Cebola", category: "Hortifruti", quantity: 25, unit: "kg", cost: 4.20, status: "ok", minStock: 10 },
  { id: 4, name: "Pão de Hambúrguer", category: "Padaria", quantity: 150, unit: "un", cost: 1.20, status: "ok", minStock: 50 },
  { id: 5, name: "Queijo Cheddar", category: "Laticínios", quantity: 8, unit: "kg", cost: 45.00, status: "ok", minStock: 5 },
  { id: 6, name: "Óleo de Soja", category: "Mercearia", quantity: 2, unit: "L", cost: 7.80, status: "critical", minStock: 10 },
]

export default function EstoquePage() {
  const [isDragging, setIsDragging] = useState(false)

  return (
    <div className="space-y-8">
      {/* Cabeçalho da Página */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-zinc-900">Estoque Inteligente</h2>
          <p className="text-zinc-500 mt-1">Gerencie seus ingredientes de forma automatizada.</p>
        </div>
        <div className="flex items-center gap-3">
          <button className="inline-flex items-center justify-center rounded-xl bg-white border border-zinc-200 px-4 py-2 text-sm font-medium text-zinc-700 shadow-sm hover:bg-zinc-50 transition-colors">
            <Plus className="mr-2 h-4 w-4" />
            Adicionar Manual
          </button>
          <button className="inline-flex items-center justify-center rounded-xl bg-emerald-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-emerald-700 transition-colors">
            <Camera className="mr-2 h-4 w-4" />
            Ler Cupom Fiscal
          </button>
        </div>
      </div>

      {/* Área de Upload / OCR */}
      <Card className={`border-2 border-dashed transition-colors ${isDragging ? 'border-emerald-500 bg-emerald-50' : 'border-zinc-300 bg-zinc-50/50'}`}>
        <CardContent className="flex flex-col items-center justify-center py-12">
          <div className="h-16 w-16 bg-white rounded-full shadow-sm flex items-center justify-center mb-4 text-emerald-600">
            <UploadCloud className="h-8 w-8" />
          </div>
          <h3 className="text-lg font-semibold text-zinc-900">Entrada Automática de Estoque</h3>
          <p className="text-sm text-zinc-500 mt-1 max-w-md text-center">
            Arraste a foto do cupom fiscal ou nota fiscal eletrônica aqui. Nossa inteligência artificial fará a leitura dos itens, quantidades e preços automaticamente.
          </p>
          <div className="mt-6 flex gap-4">
            <button className="text-sm font-medium text-emerald-600 bg-emerald-100 px-4 py-2 rounded-lg hover:bg-emerald-200 transition-colors">
              Procurar arquivo
            </button>
            <button className="text-sm font-medium text-zinc-700 bg-white border border-zinc-200 px-4 py-2 rounded-lg hover:bg-zinc-50 transition-colors flex items-center">
              <Camera className="h-4 w-4 mr-2" />
              Tirar Foto
            </button>
          </div>
        </CardContent>
      </Card>

      {/* KPIs de Estoque */}
      <div className="grid gap-6 md:grid-cols-3">
        <Card>
          <CardContent className="p-6 flex items-center gap-4">
            <div className="h-12 w-12 bg-zinc-100 text-zinc-600 rounded-full flex items-center justify-center">
              <FileText className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm font-medium text-zinc-500">Total de Itens</p>
              <h4 className="text-2xl font-bold text-zinc-900">142</h4>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 flex items-center gap-4">
            <div className="h-12 w-12 bg-rose-100 text-rose-600 rounded-full flex items-center justify-center">
              <AlertCircle className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm font-medium text-zinc-500">Itens em Alerta</p>
              <h4 className="text-2xl font-bold text-zinc-900">3</h4>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 flex items-center gap-4">
            <div className="h-12 w-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center">
              <CheckCircle2 className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm font-medium text-zinc-500">Valor em Estoque</p>
              <h4 className="text-2xl font-bold text-zinc-900">R$ 4.850,00</h4>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabela de Estoque */}
      <Card>
        <CardHeader className="flex flex-col sm:flex-row sm:items-center sm:justify-between border-b border-zinc-100 pb-4">
          <CardTitle className="text-lg">Inventário Atual</CardTitle>
          <div className="flex items-center gap-2 mt-4 sm:mt-0">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-400" />
              <input
                type="text"
                placeholder="Buscar ingrediente..."
                className="pl-9 pr-4 py-1.5 bg-zinc-50 border border-zinc-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 w-full sm:w-64"
              />
            </div>
            <button className="p-1.5 border border-zinc-200 rounded-lg text-zinc-500 hover:bg-zinc-50">
              <Filter className="h-4 w-4" />
            </button>
          </div>
        </CardHeader>
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="text-xs text-zinc-500 uppercase bg-zinc-50/50 border-b border-zinc-100">
              <tr>
                <th className="px-6 py-3 font-medium">Produto</th>
                <th className="px-6 py-3 font-medium">Categoria</th>
                <th className="px-6 py-3 font-medium">Quantidade</th>
                <th className="px-6 py-3 font-medium">Custo Unit.</th>
                <th className="px-6 py-3 font-medium">Status</th>
                <th className="px-6 py-3 font-medium text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-100">
              {mockInventory.map((item) => (
                <tr key={item.id} className="hover:bg-zinc-50/50 transition-colors">
                  <td className="px-6 py-4 font-medium text-zinc-900">{item.name}</td>
                  <td className="px-6 py-4 text-zinc-500">{item.category}</td>
                  <td className="px-6 py-4">
                    <span className="font-medium text-zinc-900">{item.quantity}</span>
                    <span className="text-zinc-500 ml-1">{item.unit}</span>
                  </td>
                  <td className="px-6 py-4 text-zinc-500">
                    R$ {item.cost.toFixed(2)}
                  </td>
                  <td className="px-6 py-4">
                    {item.status === 'ok' && (
                      <span className="inline-flex items-center px-2 py-1 rounded-md text-xs font-medium bg-emerald-50 text-emerald-700 ring-1 ring-inset ring-emerald-600/20">
                        Normal
                      </span>
                    )}
                    {item.status === 'warning' && (
                      <span className="inline-flex items-center px-2 py-1 rounded-md text-xs font-medium bg-amber-50 text-amber-700 ring-1 ring-inset ring-amber-600/20">
                        Baixo
                      </span>
                    )}
                    {item.status === 'critical' && (
                      <span className="inline-flex items-center px-2 py-1 rounded-md text-xs font-medium bg-rose-50 text-rose-700 ring-1 ring-inset ring-rose-600/20">
                        Crítico
                      </span>
                    )}
                  </td>
                  <td className="px-6 py-4 text-right">
                    <button className="text-emerald-600 hover:text-emerald-700 font-medium text-xs">
                      Editar
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  )
}
