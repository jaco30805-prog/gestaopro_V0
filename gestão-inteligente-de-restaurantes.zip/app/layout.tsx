import type { Metadata } from 'next';
import './globals.css';
import { Shell } from '@/components/layout/shell';

export const metadata: Metadata = {
  title: 'Gestão Inteligente de Restaurantes',
  description: 'Sistema digital completo para gestão de restaurantes',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <body className="bg-zinc-50 text-zinc-950 font-sans antialiased" suppressHydrationWarning>
        <Shell>{children}</Shell>
      </body>
    </html>
  );
}
