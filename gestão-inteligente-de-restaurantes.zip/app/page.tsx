"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowUpRight, ArrowDownRight, TrendingUp, AlertTriangle, DollarSign, Utensils, PackageOpen, Camera } from "lucide-react"

export default function DashboardPage() {
  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-zinc-900">Visão Geral</h2>
          <p className="text-zinc-500 mt-1">Acompanhe os resultados do seu restaurante hoje.</p>
        </div>
        <div className="flex items-center gap-3">
          <button className="inline-flex items-center justify-center rounded-xl bg-white border border-zinc-200 px-4 py-2 text-sm font-medium text-zinc-700 shadow-sm hover:bg-zinc-50 transition-colors">
            <Utensils className="mr-2 h-4 w-4" />
            Nova Venda
          </button>
          <button className="inline-flex items-center justify-center rounded-xl bg-emerald-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-emerald-700 transition-colors">
            <Camera className="mr-2 h-4 w-4" />
            Escanear Cupom
          </button>
        </div>
      </div>

      {/* KPIs Principais */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-zinc-500">
              Faturamento do dia
            </CardTitle>
            <div className="h-8 w-8 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center">
              <DollarSign className="h-4 w-4" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-zinc-900">R$ 2.180,00</div>
            <p className="text-xs text-emerald-600 flex items-center mt-1 font-medium">
              <ArrowUpRight className="h-3 w-3 mr-1" />
              +12% em relação a ontem
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-zinc-500">
              Lucro estimado
            </CardTitle>
            <div className="h-8 w-8 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center">
              <TrendingUp className="h-4 w-4" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-zinc-900">R$ 910,00</div>
            <p className="text-xs text-emerald-600 flex items-center mt-1 font-medium">
              <ArrowUpRight className="h-3 w-3 mr-1" />
              Margem de 41.7%
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-zinc-500">
              Mais lucrativo
            </CardTitle>
            <div className="h-8 w-8 bg-amber-100 text-amber-600 rounded-full flex items-center justify-center">
              <ArrowUpRight className="h-4 w-4" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-zinc-900 truncate">X-Burguer</div>
            <p className="text-xs text-zinc-500 mt-1">
              R$ 24,00 lucro/unidade
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-zinc-500">
              Menos lucrativo
            </CardTitle>
            <div className="h-8 w-8 bg-rose-100 text-rose-600 rounded-full flex items-center justify-center">
              <ArrowDownRight className="h-4 w-4" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-zinc-900 truncate">X-Salada</div>
            <p className="text-xs text-zinc-500 mt-1">
              R$ 4,50 lucro/unidade (Revisar preço)
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Alertas e Gráficos */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-7">
        <Card className="col-span-4">
          <CardHeader>
            <CardTitle>Desempenho Semanal</CardTitle>
          </CardHeader>
          <CardContent className="pl-2">
            <div className="h-[300px] w-full flex items-end justify-between px-6 pb-4 pt-8">
              {/* Simple CSS Bar Chart Placeholder */}
              {[
                { day: "Seg", rev: 1200, profit: 400 },
                { day: "Ter", rev: 1800, profit: 700 },
                { day: "Qua", rev: 1500, profit: 600 },
                { day: "Qui", rev: 2180, profit: 910 },
                { day: "Sex", rev: 0, profit: 0 },
                { day: "Sáb", rev: 0, profit: 0 },
                { day: "Dom", rev: 0, profit: 0 },
              ].map((item, i) => (
                <div key={i} className="flex flex-col items-center gap-2 w-12">
                  <div className="relative w-full h-[200px] flex items-end justify-center gap-1">
                    <div 
                      className="w-4 bg-zinc-200 rounded-t-sm transition-all" 
                      style={{ height: `${(item.rev / 2500) * 100}%` }}
                    ></div>
                    <div 
                      className="w-4 bg-emerald-500 rounded-t-sm transition-all" 
                      style={{ height: `${(item.profit / 2500) * 100}%` }}
                    ></div>
                  </div>
                  <span className="text-xs text-zinc-500 font-medium">{item.day}</span>
                </div>
              ))}
            </div>
            <div className="flex justify-center gap-6 mt-2">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-zinc-200 rounded-sm"></div>
                <span className="text-xs text-zinc-500">Faturamento</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-emerald-500 rounded-sm"></div>
                <span className="text-xs text-zinc-500">Lucro</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="col-span-3 border-rose-200 bg-rose-50/30">
          <CardHeader>
            <CardTitle className="flex items-center text-rose-700">
              <AlertTriangle className="h-5 w-5 mr-2" />
              Alertas de Estoque
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start gap-4 p-4 bg-white rounded-xl border border-rose-100 shadow-sm">
                <div className="h-10 w-10 bg-rose-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <PackageOpen className="h-5 w-5 text-rose-600" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-zinc-900">Carne dura apenas 2 dias</h4>
                  <p className="text-sm text-zinc-500 mt-1">
                    Com base no ritmo de vendas atual, o estoque de Contra-filé (12kg) vai acabar na Sexta-feira.
                  </p>
                  <button className="mt-3 text-xs font-medium text-rose-600 hover:text-rose-700">
                    Adicionar à lista de compras &rarr;
                  </button>
                </div>
              </div>

              <div className="flex items-start gap-4 p-4 bg-white rounded-xl border border-amber-100 shadow-sm">
                <div className="h-10 w-10 bg-amber-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <PackageOpen className="h-5 w-5 text-amber-600" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-zinc-900">Tomate próximo do vencimento</h4>
                  <p className="text-sm text-zinc-500 mt-1">
                    5kg de tomate vencem em 3 dias. Sugestão: Criar promoção de pratos com molho.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
