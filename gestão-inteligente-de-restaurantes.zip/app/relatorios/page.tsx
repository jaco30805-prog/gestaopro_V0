"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Calendar, Download, TrendingUp, DollarSign, PieChart, BarChart3, ArrowUpRight, ArrowDownRight } from "lucide-react"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from "recharts"

const monthlyData = [
  { name: 'Sem 1', revenue: 12000, cost: 7000, profit: 5000 },
  { name: 'Sem 2', revenue: 15000, cost: 8500, profit: 6500 },
  { name: 'Sem 3', revenue: 14000, cost: 8000, profit: 6000 },
  { name: 'Sem 4', revenue: 18000, cost: 9500, profit: 8500 },
]

const topProducts = [
  { name: "X-Burguer Clássico", value: 35 },
  { name: "Refrigerante Lata", value: 25 },
  { name: "Batata Frita", value: 20 },
  { name: "Combo Família", value: 15 },
  { name: "Outros", value: 5 },
]

export default function RelatoriosPage() {
  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-zinc-900">Relatórios Financeiros</h2>
          <p className="text-zinc-500 mt-1">Análise detalhada de faturamento, custos e lucratividade.</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative">
            <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-400" />
            <select className="pl-10 pr-8 py-2 bg-white border border-zinc-200 rounded-xl text-sm font-medium text-zinc-700 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 appearance-none cursor-pointer">
              <option>Este Mês (Outubro)</option>
              <option>Mês Passado (Setembro)</option>
              <option>Últimos 3 Meses</option>
              <option>Este Ano</option>
            </select>
          </div>
          <button className="inline-flex items-center justify-center rounded-xl bg-white border border-zinc-200 px-4 py-2 text-sm font-medium text-zinc-700 shadow-sm hover:bg-zinc-50 transition-colors">
            <Download className="mr-2 h-4 w-4" />
            Exportar PDF
          </button>
        </div>
      </div>

      {/* Resumo Financeiro */}
      <div className="grid gap-6 md:grid-cols-4">
        <Card className="bg-zinc-900 text-white border-zinc-800">
          <CardContent className="p-6">
            <p className="text-sm font-medium text-zinc-400">Faturamento Total</p>
            <div className="text-3xl font-bold mt-2">R$ 59.000</div>
            <p className="text-xs text-emerald-400 flex items-center mt-2 font-medium">
              <ArrowUpRight className="h-3 w-3 mr-1" />
              +15% vs mês anterior
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <p className="text-sm font-medium text-zinc-500">Custo de Mercadoria (CMV)</p>
            <div className="text-3xl font-bold text-zinc-900 mt-2">R$ 33.000</div>
            <p className="text-xs text-rose-600 flex items-center mt-2 font-medium">
              <ArrowUpRight className="h-3 w-3 mr-1" />
              55.9% do faturamento
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <p className="text-sm font-medium text-zinc-500">Lucro Bruto</p>
            <div className="text-3xl font-bold text-emerald-600 mt-2">R$ 26.000</div>
            <p className="text-xs text-emerald-600 flex items-center mt-2 font-medium">
              <ArrowUpRight className="h-3 w-3 mr-1" />
              Margem de 44.1%
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <p className="text-sm font-medium text-zinc-500">Desperdício Estimado</p>
            <div className="text-3xl font-bold text-zinc-900 mt-2">R$ 850</div>
            <p className="text-xs text-emerald-600 flex items-center mt-2 font-medium">
              <ArrowDownRight className="h-3 w-3 mr-1" />
              -5% vs mês anterior
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        {/* Gráfico de Faturamento vs Lucro */}
        <Card className="col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center">
              <BarChart3 className="h-5 w-5 mr-2 text-zinc-500" />
              Evolução de Faturamento e Lucro
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px] w-full mt-4">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={monthlyData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e4e4e7" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#71717a', fontSize: 12 }} dy={10} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fill: '#71717a', fontSize: 12 }} tickFormatter={(value) => `R$${value/1000}k`} />
                  <Tooltip 
                    cursor={{ fill: '#f4f4f5' }}
                    contentStyle={{ borderRadius: '12px', border: '1px solid #e4e4e7', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                    formatter={(value: any) => [`R$ ${value}`, '']}
                  />
                  <Bar dataKey="revenue" name="Faturamento" fill="#18181b" radius={[4, 4, 0, 0]} barSize={32} />
                  <Bar dataKey="profit" name="Lucro" fill="#10b981" radius={[4, 4, 0, 0]} barSize={32} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Produtos Mais Vendidos */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <PieChart className="h-5 w-5 mr-2 text-zinc-500" />
              Top Produtos (Volume)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6 mt-4">
              {topProducts.map((product, index) => (
                <div key={index} className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="font-medium text-zinc-900">{product.name}</span>
                    <span className="text-zinc-500">{product.value}%</span>
                  </div>
                  <div className="w-full bg-zinc-100 rounded-full h-2">
                    <div 
                      className="bg-emerald-500 h-2 rounded-full" 
                      style={{ width: `${product.value}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-8 p-4 bg-emerald-50 rounded-xl border border-emerald-100">
              <h4 className="text-sm font-semibold text-emerald-900 flex items-center">
                <TrendingUp className="h-4 w-4 mr-1" /> Insight do Mês
              </h4>
              <p className="text-sm text-emerald-700 mt-1">
                O "Combo Família" teve um aumento de 15% nas vendas. Sugerimos criar uma variação deste combo para aumentar o ticket médio.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
