"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Plus, Search, UploadCloud, Receipt, DollarSign, CreditCard, Clock, CheckCircle2 } from "lucide-react"

const mockSales = [
  { id: "V-1042", time: "14:32", items: "2x X-Burguer, 1x Coca-Cola", total: 54.00, method: "Cartão de Crédito", status: "completed" },
  { id: "V-1041", time: "14:15", items: "1x Combo Família", total: 69.90, method: "PIX", status: "completed" },
  { id: "V-1040", time: "13:50", items: "1x X-Salada, 1x Suco Laranja", total: 23.00, method: "Dinheiro", status: "completed" },
  { id: "V-1039", time: "13:45", items: "3x Batata Frita, 3x Chopp", total: 96.00, method: "Cartão de Débito", status: "completed" },
  { id: "V-1038", time: "13:20", items: "1x Hambúrguer Artesanal Duplo", total: 38.00, method: "PIX", status: "completed" },
]

export default function VendasPage() {
  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-zinc-900">Registro de Vendas</h2>
          <p className="text-zinc-500 mt-1">Acompanhe as vendas do dia e importe relatórios do seu PDV.</p>
        </div>
        <div className="flex items-center gap-3">
          <button className="inline-flex items-center justify-center rounded-xl bg-white border border-zinc-200 px-4 py-2 text-sm font-medium text-zinc-700 shadow-sm hover:bg-zinc-50 transition-colors">
            <UploadCloud className="mr-2 h-4 w-4" />
            Importar Relatório (PDV)
          </button>
          <button className="inline-flex items-center justify-center rounded-xl bg-emerald-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-emerald-700 transition-colors">
            <Plus className="mr-2 h-4 w-4" />
            Nova Venda Manual
          </button>
        </div>
      </div>

      {/* KPIs de Vendas */}
      <div className="grid gap-6 md:grid-cols-3">
        <Card>
          <CardContent className="p-6 flex items-center gap-4">
            <div className="h-12 w-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center">
              <DollarSign className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm font-medium text-zinc-500">Vendas Hoje</p>
              <h4 className="text-2xl font-bold text-zinc-900">R$ 2.180,00</h4>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 flex items-center gap-4">
            <div className="h-12 w-12 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center">
              <Receipt className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm font-medium text-zinc-500">Total de Pedidos</p>
              <h4 className="text-2xl font-bold text-zinc-900">42</h4>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 flex items-center gap-4">
            <div className="h-12 w-12 bg-purple-100 text-purple-600 rounded-full flex items-center justify-center">
              <CreditCard className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm font-medium text-zinc-500">Ticket Médio</p>
              <h4 className="text-2xl font-bold text-zinc-900">R$ 51,90</h4>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabela de Vendas Recentes */}
      <Card>
        <CardHeader className="flex flex-col sm:flex-row sm:items-center sm:justify-between border-b border-zinc-100 pb-4">
          <CardTitle className="text-lg">Últimas Vendas</CardTitle>
          <div className="relative mt-4 sm:mt-0">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-400" />
            <input
              type="text"
              placeholder="Buscar por ID ou item..."
              className="pl-9 pr-4 py-1.5 bg-zinc-50 border border-zinc-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 w-full sm:w-64"
            />
          </div>
        </CardHeader>
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="text-xs text-zinc-500 uppercase bg-zinc-50/50 border-b border-zinc-100">
              <tr>
                <th className="px-6 py-3 font-medium">ID Pedido</th>
                <th className="px-6 py-3 font-medium">Horário</th>
                <th className="px-6 py-3 font-medium">Itens</th>
                <th className="px-6 py-3 font-medium">Pagamento</th>
                <th className="px-6 py-3 font-medium">Total</th>
                <th className="px-6 py-3 font-medium text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-100">
              {mockSales.map((sale) => (
                <tr key={sale.id} className="hover:bg-zinc-50/50 transition-colors">
                  <td className="px-6 py-4 font-medium text-zinc-900">{sale.id}</td>
                  <td className="px-6 py-4 text-zinc-500 flex items-center">
                    <Clock className="h-3 w-3 mr-1" /> {sale.time}
                  </td>
                  <td className="px-6 py-4 text-zinc-500 truncate max-w-[200px]">{sale.items}</td>
                  <td className="px-6 py-4 text-zinc-500">{sale.method}</td>
                  <td className="px-6 py-4 font-medium text-zinc-900">
                    R$ {sale.total.toFixed(2)}
                  </td>
                  <td className="px-6 py-4 text-right">
                    <span className="inline-flex items-center px-2 py-1 rounded-md text-xs font-medium bg-emerald-50 text-emerald-700 ring-1 ring-inset ring-emerald-600/20">
                      <CheckCircle2 className="h-3 w-3 mr-1" /> Concluído
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="p-4 border-t border-zinc-100 text-center">
          <button className="text-sm font-medium text-emerald-600 hover:text-emerald-700">
            Ver todas as vendas &rarr;
          </button>
        </div>
      </Card>
    </div>
  )
}
