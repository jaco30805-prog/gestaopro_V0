"use client"

import { Bell, Search, User, Menu } from "lucide-react"

export function Header({ onOpenMobileMenu }: { onOpenMobileMenu?: () => void }) {
  return (
    <div className="h-16 flex items-center justify-between px-4 md:px-8 border-b border-zinc-200 bg-white">
      <div className="flex items-center flex-1 gap-3">
        <button onClick={onOpenMobileMenu} className="md:hidden p-2 -ml-2 text-zinc-500 hover:bg-zinc-100 rounded-lg transition-colors">
          <Menu className="h-5 w-5" />
        </button>
        <div className="relative w-full max-w-md hidden sm:block">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-400" />
          <input
            type="text"
            placeholder="Buscar pratos, ingredientes ou relatórios..."
            className="w-full pl-10 pr-4 py-2 bg-zinc-50 border border-zinc-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
          />
        </div>
      </div>
      <div className="flex items-center space-x-3 md:space-x-4">
        <button className="sm:hidden relative p-2 text-zinc-500 hover:bg-zinc-100 rounded-full transition-colors">
          <Search className="h-5 w-5" />
        </button>
        <button className="relative p-2 text-zinc-500 hover:bg-zinc-100 rounded-full transition-colors">
          <Bell className="h-5 w-5" />
          <span className="absolute top-1.5 right-1.5 h-2 w-2 bg-rose-500 rounded-full border-2 border-white"></span>
        </button>
        <div className="h-8 w-8 bg-emerald-100 rounded-full flex items-center justify-center border border-emerald-200 cursor-pointer">
          <User className="h-4 w-4 text-emerald-700" />
        </div>
      </div>
    </div>
  )
}
