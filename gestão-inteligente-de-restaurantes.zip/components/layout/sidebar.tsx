"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import {
  LayoutDashboard,
  Package,
  UtensilsCrossed,
  Receipt,
  FileText,
  Settings,
  Store
} from "lucide-react"

const routes = [
  {
    label: "Dashboard",
    icon: LayoutDashboard,
    href: "/",
    color: "text-zinc-900",
  },
  {
    label: "Estoque (Auto)",
    icon: Package,
    href: "/estoque",
    color: "text-zinc-900",
  },
  {
    label: "Cardápio",
    icon: UtensilsCrossed,
    href: "/cardapio",
    color: "text-zinc-900",
  },
  {
    label: "Vendas",
    icon: Receipt,
    href: "/vendas",
    color: "text-zinc-900",
  },
  {
    label: "Relatórios",
    icon: FileText,
    href: "/relatorios",
    color: "text-zinc-900",
  },
  {
    label: "Configurações",
    icon: Settings,
    href: "/configuracoes",
    color: "text-zinc-900",
  },
]

export function Sidebar({ onClose }: { onClose?: () => void }) {
  const pathname = usePathname()

  return (
    <div className="space-y-4 py-4 flex flex-col h-full bg-zinc-50 border-r border-zinc-200">
      <div className="px-3 py-2 flex-1">
        <Link href="/" onClick={onClose} className="flex items-center pl-3 mb-14">
          <div className="relative w-8 h-8 mr-4 bg-emerald-600 rounded-lg flex items-center justify-center">
            <Store className="h-5 w-5 text-white" />
          </div>
          <h1 className="text-xl font-bold text-zinc-900 tracking-tight">
            Gestão<span className="text-emerald-600">Pro</span>
          </h1>
        </Link>
        <div className="space-y-1">
          {routes.map((route) => (
            <Link
              key={route.href}
              href={route.href}
              onClick={onClose}
              className={cn(
                "text-sm group flex p-3 w-full justify-start font-medium cursor-pointer hover:bg-zinc-200/50 rounded-xl transition",
                pathname === route.href ? "bg-zinc-200/80 text-zinc-900" : "text-zinc-600"
              )}
            >
              <div className="flex items-center flex-1">
                <route.icon className={cn("h-5 w-5 mr-3", route.color)} />
                {route.label}
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  )
}
